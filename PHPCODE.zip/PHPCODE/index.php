<?php
echo "Hello";
echo "<br>"; // Added semicolon here
echo "Ahmed";
$a = 20;
$b = 2.3;


//here i want to declare variables 

echo "<br>";
echo $a;
echo "<br>";
echo $b;
?>

<html>
    <head>
        <style>
            h1 {
                color: red;
            }
        </style>
    </head>
    <body> <!-- Added the <body> tag to enclose the content -->
        <h1>Hi I'm Ahmed</h1>
    </body> <!-- Closed the <body> tag -->
</html>
